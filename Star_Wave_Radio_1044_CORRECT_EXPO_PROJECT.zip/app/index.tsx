import React, { useEffect, useState } from 'react';
import { Linking, Pressable, SafeAreaView, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Audio } from 'expo-av';

const STREAM_URL = 'http://s11.myradiostream.com:26666/stream';
const WHATSAPP = 'https://wa.me/256751085833';
const LISTEN_PAGE = 'https://mickierays.on-air.fm';

const programmes = [
  ['Monday', 'Good Morning Waves', '7:00 AM – 10:00 AM'],
  ['Monday', 'News Hour', '1:00 PM – 2:00 PM'],
  ['Tuesday', 'Good Morning Waves', '7:00 AM – 10:00 AM'],
  ['Wednesday', 'Good Morning Waves', '7:00 AM – 10:00 AM'],
  ['Thursday', 'Good Morning Waves', '7:00 AM – 10:00 AM'],
  ['Friday', 'Good Morning Waves', '7:00 AM – 10:00 AM'],
  ['Saturday', 'Weekend Waves', '9:00 AM – 12:00 PM'],
  ['Sunday', 'Sunday Vibes', '10:00 AM – 1:00 PM'],
  ['Daily', 'Night Vibes', '10:00 PM – 12:00 AM']
];

export default function Home() {
  const [sound, setSound] = useState<Audio.Sound | null>(null);
  const [playing, setPlaying] = useState(false);

  useEffect(() => {
    return () => { sound?.unloadAsync(); };
  }, [sound]);

  async function toggleLive() {
    if (sound) {
      if (playing) {
        await sound.pauseAsync();
        setPlaying(false);
      } else {
        await sound.playAsync();
        setPlaying(true);
      }
      return;
    }
    try {
      const { sound: newSound } = await Audio.Sound.createAsync(
        { uri: STREAM_URL },
        { shouldPlay: true }
      );
      setSound(newSound);
      setPlaying(true);
    } catch {
      Linking.openURL(LISTEN_PAGE);
    }
  }

  return (
    <SafeAreaView style={styles.safe}>
      <ScrollView contentContainerStyle={styles.container}>
        <View style={styles.header}>
          <Text style={styles.logo}>★</Text>
          <View>
            <Text style={styles.title}>STAR WAVE RADIO</Text>
            <Text style={styles.frequency}>104.4 FM</Text>
          </View>
        </View>

        <Text style={styles.slogan}>Pure Sound • Great Vibes</Text>

        <View style={styles.liveCard}>
          <Text style={styles.liveLabel}>🔴 LIVE ON AIR</Text>
          <Text style={styles.now}>Star Wave Radio 104.4 FM</Text>
          <Pressable style={styles.play} onPress={toggleLive}>
            <Text style={styles.playText}>{playing ? '⏸  PAUSE LIVE' : '▶  LISTEN LIVE'}</Text>
          </Pressable>
          <Pressable onPress={() => Linking.openURL(LISTEN_PAGE)}>
            <Text style={styles.link}>Open online player</Text>
          </Pressable>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Programme Schedule</Text>
          {programmes.map(([day, name, time], i) => (
            <View style={styles.row} key={i}>
              <Text style={styles.day}>{day}</Text>
              <View style={{flex: 1}}>
                <Text style={styles.programme}>{name}</Text>
                <Text style={styles.time}>{time}</Text>
              </View>
            </View>
          ))}
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>Requests & Advertising</Text>
          <Pressable style={styles.action} onPress={() => Linking.openURL(WHATSAPP)}>
            <Text style={styles.actionText}>💬 WhatsApp Song Request</Text>
          </Pressable>
          <Pressable style={styles.action} onPress={() => Linking.openURL(WHATSAPP)}>
            <Text style={styles.actionText}>📢 Advertise With Star Wave</Text>
          </Pressable>
          <Text style={styles.contact}>WhatsApp: 0751 085833</Text>
        </View>

        <View style={styles.section}>
          <Text style={styles.sectionTitle}>About Star Wave</Text>
          <Text style={styles.body}>
            Star Wave Radio 104.4 FM brings music, entertainment, news, community
            programmes and great vibes to listeners. Listen live online and send
            your requests through WhatsApp.
          </Text>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: '#071426' },
  container: { padding: 20, paddingBottom: 40 },
  header: { flexDirection: 'row', alignItems: 'center', gap: 14, marginTop: 20 },
  logo: { width: 58, height: 58, borderRadius: 29, backgroundColor: '#d71920', color: '#fff', textAlign: 'center', textAlignVertical: 'center', fontSize: 30 },
  title: { color: '#fff', fontSize: 23, fontWeight: '800' },
  frequency: { color: '#f2c94c', fontSize: 18, fontWeight: '700', marginTop: 2 },
  slogan: { color: '#b9c7d8', marginTop: 12, fontSize: 15 },
  liveCard: { backgroundColor: '#10233d', borderRadius: 18, padding: 20, marginTop: 22, alignItems: 'center' },
  liveLabel: { color: '#ff5964', fontWeight: '800', marginBottom: 10 },
  now: { color: '#fff', fontSize: 18, fontWeight: '700', textAlign: 'center' },
  play: { backgroundColor: '#d71920', paddingVertical: 14, paddingHorizontal: 28, borderRadius: 30, marginTop: 18 },
  playText: { color: '#fff', fontWeight: '800' },
  link: { color: '#7ec8ff', marginTop: 14 },
  section: { marginTop: 24, backgroundColor: '#0d1d32', borderRadius: 16, padding: 16 },
  sectionTitle: { color: '#f2c94c', fontSize: 19, fontWeight: '800', marginBottom: 12 },
  row: { flexDirection: 'row', paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: '#1d3048', gap: 12 },
  day: { color: '#9fb1c5', width: 62, fontWeight: '700' },
  programme: { color: '#fff', fontWeight: '700' },
  time: { color: '#9fb1c5', marginTop: 3 },
  action: { backgroundColor: '#d71920', padding: 14, borderRadius: 12, marginTop: 10 },
  actionText: { color: '#fff', textAlign: 'center', fontWeight: '800' },
  contact: { color: '#9fb1c5', textAlign: 'center', marginTop: 12 },
  body: { color: '#c4cfdb', lineHeight: 22, fontSize: 15 }
});