# Star Wave Radio 104.4 FM

Clean Expo/EAS Android project for Star Wave Radio 104.4 FM.

## Important
Upload the CONTENTS of this folder to GitHub. Do not upload an old prototype or a different Android project.

Required structure:
- app/_layout.tsx
- app/index.tsx
- package.json
- app.json
- eas.json
- tsconfig.json

The preview EAS profile produces an Android APK.

Live stream:
http://s11.myradiostream.com:26666/stream

Online player:
https://mickierays.on-air.fm

WhatsApp:
0751 085833
